package sk.uniza.fri;

import sk.uniza.fri.pouzivatelia.Hrac;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * 18. 4. 2022 - 15:45
 * generická trieda pre ukladanie hráčov, obmedzuje parameter na potomkov triedy Hrac
 * @author panak
 */
public class Zoznam <E extends Hrac> implements Iterable<E> {
    private final ArrayList<E> hraci;

    public Zoznam() {
        this.hraci = new ArrayList<>();
    }

    public void pridajHraca (E hrac) {
        this.hraci.add(hrac);
    }

    /**
     * vráti instanciu hráca podla zadaneho id
     * @param id id hraca
     * @return inštancia hráča
     */
    public E getHraca(int id) {
        E najdeny = null;
        for (E e : this.hraci) {
            if (e.getId() == id) {
                najdeny = e;
            }
        }
        return najdeny;
    }

    /**
     *
     * @return vráti velkosť zoznamu
     */
    public int size() {
        return this.hraci.size();
    }

    /**
     * vráti hráca podľa zadaného indexu
     * @param index index hrača
     * @return inštanciu hráča
     */
    public E get(int index) {
        return this.hraci.get(index);
    }

    /**
     * metóda slúži na následne prehľadávanie zoznamu
     * @return
     */
    @Override
    public Iterator<E> iterator() {
        return this.hraci.iterator();
    }

    /**
     * odstranuje hraca zo zoznamu
     * @param h instancia hraca
     * @return instancia odstraneneho hraca
     */
    public E odstranHraca(Hrac h) {
        for (int i = 0; i < this.hraci.size(); i++) {
            if (this.hraci.get(i).equals(h)) {
                return this.hraci.remove(i);
            }
        }
        return null;
    }
}
