package sk.uniza.fri.pouzivatelia;

import sk.uniza.fri.Narocnost;

import javax.swing.JOptionPane;

/**
 * Trieda Hráč vytvorí hráča so všetkými potrebnými údajmi. implementuje interface IPouzivatel
 * 
 * @author (Rebeka Panáková) 
 * @version (12.12.2021)
 */
public class Hrac implements IPouzivatel {
    //atribúty inštancie
    private final int id;
    private String meno;
    private int skore;
    private boolean[] zivoty;
    private Narocnost narocnost;
    private final String level;

    
    /**
     * Konštruktor vytvorí nového hráča pred začatím hry
     * @param meno priradí meno hráčovi
     */
    public Hrac(String meno, int id) {
        // inicializacia atribútov
        this.id = id;
        this.meno = meno; 
        this.skore = 0;
        this.level = "Začiatočník";
    }

    /**
     * Konštruktor vytvorí hráča po načítaní zo súboru
     * @param meno priradí zadané meno
     * @param dosiahnuteSkore priradí dosiahnute skóre
     * @param level priradí zvolenú náročnosť
     */
    public Hrac (int id, String meno, int dosiahnuteSkore, String level) {
        //inicializácia atribútov
        this.id = id;
        this.meno = meno;
        this.skore = dosiahnuteSkore;
        this.level = level;
    }


    public String getLevel() {
        return this.level;
    }
    /**
     * Výber náročnosti podľa hráča z ponuky prednastavených náročností
     */
    public Narocnost setNarocnost() {
        String[] narocnosti = {"ľahka", "stredna", "ťažka"};
        int volba = JOptionPane.showOptionDialog(null, "Zvoľ si náročnosť", "Voľba", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, narocnosti, 0);
        switch (volba) {
            case 0:
                this.narocnost = Narocnost.LAHKA;
                break;
            case 1:
                this.narocnost = Narocnost.STREDNA;
                break;
            case 2:
                this.narocnost = Narocnost.TAZKA;
                break;
            default:
            //v prípade nevybrania ponuky rekurziou opäť zavoláme túto metódu
                this.setNarocnost();
        }
        return this.narocnost;
    }

    public int getId() {
        return this.id;
    }

    /**
     * zoberie hráčovi všetky životy
     */
    public void uberZivot() {
        if (this.zivoty[0]) {
            this.zivoty[this.getPocetZivotov() - 1] = false;
        }
    }

    /**
     * @return aktuálne skóre
     */
    public int getSkore() {
        return this.skore;
    }


    /**
     * @return meno hráča
     */
    public String getMeno() {
        return this.meno;
    }
    

    /**
     * vytvorí hráčovi daný počet životov
     */

    public void setZivoty(int pocet) {
        this.zivoty = new boolean[pocet];
        for (int i = 0; i < this.zivoty.length; i++) {
            this.zivoty[i] = true;
        }
    }

    /**
     * pripíše hráčovi skóre
     */
    public void pripisSkore() {
        this.skore++;
    }

    /**
     * implementovaná ometóda pre znakovú reprezentáciu objektu
     * @return
     */
    @Override
    public String vypis() {
        return String.format("%d. %s \tskóre: \t%d \t[%s]", this.getId(), this.getMeno(), this.getSkore(), this.getLevel());

    }

    /**
     * implementovaná ometóda pre znakovú reprezentáciu objektu pre zápis do súboru
     * @return
     */
    @Override
    public String toString() {
        return  this.id + " " + this.meno + " " + this.skore + " " + this.getLevel();
    }

    /**
     * zistí počet životov
     * @return vráti počet
     */
    public int getPocetZivotov() {
        int i = 0;
        for (boolean z : this.zivoty) {
            if (z) {
                i++;
            }
        }
        return i;
    }

    /**
     * pridá jeden život
     */
    public void pridajZivot() {
        if (this.getPocetZivotov() != this.zivoty.length) {
            this.zivoty[this.getPocetZivotov()] = true;
        }
    }

    /**
     * setter na meno
     * @param noveMeno
     */
    public void setMeno(String noveMeno) {
        this.meno = noveMeno;
    }
}
