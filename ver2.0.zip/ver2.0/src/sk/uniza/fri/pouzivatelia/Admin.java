package sk.uniza.fri.pouzivatelia;

import sk.uniza.fri.Zoznam;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.BorderLayout;


/**
 * 18. 4. 2022 - 15:45
 * Admin v hre sluzi na spravovanie hrácov
 * @author panak
 */
public class Admin implements IPouzivatel {
    private final String meno;
    private String heslo;
    private final int id;
    private Zoznam<Pokrocily> pokrocilyZoznam;
    private Zoznam<Zaciatocnik> zaciatocnikZoznam;

    private JTextField lebelIdUpraveneho;

    //private Hra hra;
    public Admin(String meno, String heslo) {
        this.meno = meno;
        this.heslo = heslo;
        this.id = 1;
    }

    /**
     * metoda vytvori štruktúru pre prihlasenie admina, načítava z polí pre meno a heslo
     * @return obraz prihlasenia
     */
    public JLabel getPrihlLabel() {
        JLabel label = new JLabel();
        label.setBounds(0, 0, 350, 500);
        label.setBackground(new Color(204, 242, 255));

        label.setLayout(new BorderLayout(2, 2));
        JButton btnUpravHraca = new JButton("Uprav hráča");
        btnUpravHraca.setBackground(new Color(208, 248, 255));
        label.add(btnUpravHraca);

        label.setVisible(true);
        return label;
    }

    public String getMeno() {
        return this.meno;
    }

    public String getHeslo() {
        return this.heslo;
    }

    /**
     * setter pre heslo
     * @param nove
     */
    public void setHeslo(String nove) {
        this.heslo = nove;
    }

    /**
     * implementované z interface
     * @return znakuvú reprezentáciu objektu
     */
    @Override
    public String vypis() {
        return String.format("%d. %s [Admin]", this.getId(), this.getMeno());
    }

    /**
     * getter
     * @return id objektu
     */
    @Override
    public int getId() {
        return this.id;
    }
}
