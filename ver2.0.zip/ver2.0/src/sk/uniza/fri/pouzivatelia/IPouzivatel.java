package sk.uniza.fri.pouzivatelia;

/**
 * 27. 3. 2022 - 19:33
 * trieda prínúti triedy, ktoré ju budú implementovať, aby obsahovala tieto metódy
 * @author panak
 */
public interface IPouzivatel {
    String vypis();
    int getId();
}
