package sk.uniza.fri.pouzivatelia;

/**
 * 27. 3. 2022 - 19:33
 * tireda je potomkom hráča, každý pokročilý hráč má k dispozícii prispôsobenia si režimu hry
 * @author panak
 */
public class Pokrocily extends Hrac {

    /**
     * konstruktor vytvorí inštanciu pokročilého hráča
     * @param id priradí mu id
     * @param meno zadá meno
     * @param dosiahnuteSkore priradí dosiaľ dosiahnuté skóre
     */
    public Pokrocily(int id, String meno, int dosiahnuteSkore) {
        super(id, meno, dosiahnuteSkore, "Pokročilý");
    }


}

