package sk.uniza.fri.pouzivatelia;


/**
 * 27. 3. 2022 - 19:33
 * tireda je potomkom hráča, po dosiahnutí vyššieho skóre môže postôpiť na vyššiu úroven
 * @author panak
 */
public class Zaciatocnik extends Hrac {

    /**
     * preťažený konštruktor
     * vytvorenie nového hráča
     * @param meno meno
     * @param id id
     */
    public Zaciatocnik(String meno, int id) {
        super(meno, id);
    }

    /**
     * preťažený konštruktor
     * vytvorenie hráča po načítaní zo súboru
     * @param id id
     * @param meno meno
     * @param dosiahnuteSkore dosiahnuté skóre
     */
    public Zaciatocnik(int id, String meno, int dosiahnuteSkore) {
        super(id, meno, dosiahnuteSkore, "Začiatočník" );
    }

}
