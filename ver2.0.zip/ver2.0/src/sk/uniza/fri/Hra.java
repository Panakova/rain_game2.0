package sk.uniza.fri;

import sk.uniza.fri.gui.GuiMenu;
import sk.uniza.fri.pouzivatelia.Admin;
import sk.uniza.fri.pouzivatelia.Pokrocily;
import sk.uniza.fri.pouzivatelia.Zaciatocnik;
import sk.uniza.fri.pouzivatelia.Hrac;
import sk.uniza.fri.vynimky.HracNenajdenyException;

/**
 * 18. 4. 2022 - 15:45
 * trieda spravuje chod hry
 * @author panak
 */
public class Hra {
    private int id;
    private final GuiMenu myGuiMenu;
    private Admin admin;
    private final Zoznam<Zaciatocnik> zaciatocnici;
    private final Zoznam<Pokrocily> pokrocili;

    /**
     * konštruktor inicializuje počiatočné hodnoty a načíta hru zo súboru
     */
    public Hra() {
        this.zaciatocnici = new Zoznam<>();
        this.pokrocili = new Zoznam<>();
        Ukladanie.nacitajHru(this);
        this.admin = Ukladanie.nacitajAdmina();
        this.myGuiMenu = new GuiMenu(this, this.admin);
        this.id = this.nacitajId();
    }

    /**
     * načítavá posledne použíté skóre
     * @return posledne použíté skóre
     */
    private int nacitajId() {
        int najvacsieId = 1;
        for (Zaciatocnik z : this.zaciatocnici) {
            if (z.getId() > najvacsieId) {
                najvacsieId = z.getId();
            }
        }
        for (Pokrocily p : this.pokrocili) {
            if (p.getId() > najvacsieId) {
                najvacsieId = p.getId();
            }
        }
        return najvacsieId;
    }

    /**
     * priraduje posledne použité skóre
     * @return
     */
    public int priradId() {
        this.id++;
        return this.id;
    }
    public void setAdmina(Admin a) {
        this.admin = a;
    }


    public Zoznam<Zaciatocnik> getZaciatocnici() {
        return this.zaciatocnici;
    }

    public Zoznam<Pokrocily> getPokrocili() {
        return this.pokrocili;
    }

    /**
     * metóda pridá hráča do príslušneho zoznamu
     * @param hrac
     */
    public void pridajHraca(Hrac hrac) {
        if (hrac instanceof Zaciatocnik) {
            this.zaciatocnici.pridajHraca((Zaciatocnik)hrac);
        } else if (hrac instanceof Pokrocily) {
            this.pokrocili.pridajHraca((Pokrocily)hrac);
        }
    }

    /**
     * hráča s vyšším skóre preradí do zoznamu pokročilých, odomkú sa mu rozšírené možnosti
     */
    public void kontorlujHracov() {
        for (int i = 0; i < this.zaciatocnici.size(); i++) {
            if (this.zaciatocnici.get(i).getSkore() > 50) {
                //pretypovanie
                Hrac zaciatocnik = this.zaciatocnici.odstranHraca(this.zaciatocnici.get(i));
                this.pridajHraca(new Pokrocily(zaciatocnik.getId(), zaciatocnik.getMeno(), zaciatocnik.getSkore()));
            }
        }
    }

    public Admin getAdmin() {
        return this.admin;
    }

    /**
     * metóda prehľadáva zoznamy hráčov
     * @param h hľadaný hráč
     * @return index hráča
     * @throws HracNenajdenyException v prípade nenajdeného hráča
     */
    public int getIndexHraca(Hrac h) throws HracNenajdenyException {
        if (h instanceof Zaciatocnik) {
            for (int i =  0; i < this.zaciatocnici.size(); i++) {
                if (h.equals(this.zaciatocnici.get(i))) {
                    return i;
                }
            }
        } else if (h instanceof Pokrocily) {
            for (int i =  0; i < this.pokrocili.size(); i++) {
                if (h.equals(this.pokrocili.get(i))) {
                    return i;
                }
            }
        }
        throw new HracNenajdenyException();
    }
}
