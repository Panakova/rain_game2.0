package sk.uniza.fri.gui;

import sk.uniza.fri.Hra;
import sk.uniza.fri.Zoznam;
import sk.uniza.fri.pouzivatelia.Pokrocily;
import sk.uniza.fri.pouzivatelia.Zaciatocnik;
import sk.uniza.fri.pouzivatelia.Hrac;
import javax.swing.JFrame;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.Toolkit;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import sk.uniza.fri.vynimky.NespravneVyplnenePoleException;

import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;

/**
 * 18. 4. 2022 - 15:45
 * rozhranie pre voľbu hráča, ktorý ide hrať hru
 * @author panak
 */
public class GuiHrac {
    private final JFrame frame;
    private JPanel hlPanel;
    private JLabel nazovLb;
    private JTable playerTable;
    private JScrollPane scrollPn;
    private JButton addBtn;
    private JButton playBtn;
    private final DefaultTableModel table;
    private Hrac aktualnyHrac;
    private final Hra hra;
    private final Zoznam<Hrac> zoznamHracov;

    /**
     * vytvorenie používateľského prostredia pre pre voľbu hráča, ktorý ide hrať hru
     * @param hra hra
     */
    public GuiHrac(Hra hra) {
        this.hra = hra;
        this.zoznamHracov = new Zoznam<>();
        for (Zaciatocnik z : this.hra.getZaciatocnici()) {
            this.zoznamHracov.pridajHraca(z);
        }
        for (Pokrocily p : this.hra.getPokrocili()) {
            this.zoznamHracov.pridajHraca(p);
        }
        this.frame = new JFrame("Hráč");
        ImageIcon icon = new ImageIcon("C:/Users/panak/IdeaProjects/ver2.0/src/sk/uniza/fri/pics/kvet.png");
        this.frame.setIconImage(icon.getImage());
        this.frame.setResizable(false);
        this.frame.setContentPane(this.hlPanel);
        Toolkit t = Toolkit.getDefaultToolkit();
        Dimension d = t.getScreenSize();
        this.frame.setLocation(d.width / 50 * 20, d.height / 50 * 10);
        this.frame.pack();
        this.frame.setVisible(true);
        this.table = new DefaultTableModel(
                new Object[][] {
                },
                new String [] {"Id", "Meno", "Skóre", "Level"}
        );
        this.playerTable.setModel(this.table);
        this.playerTable.getTableHeader().setReorderingAllowed(false);
        for (Hrac hrac : this.zoznamHracov) {
            this.pridajHracaDoTabulky(hrac);
        }
        this.addBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GuiHrac.this.vytvorHraca();
            }
        });
        this.playBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int indexAktualneho = GuiHrac.this.playerTable.getSelectedRow();
                    GuiHrac.this.aktualnyHrac = GuiHrac.this.zoznamHracov.get(indexAktualneho);
                    new HraFrame(GuiHrac.this.hra, GuiHrac.this.aktualnyHrac);
                    GuiHrac.this.frame.dispose();
                } catch (IndexOutOfBoundsException ex) {
                    JOptionPane.showMessageDialog(null, "Zvoľ si hráča", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }

    /**
     * vloženia hráča do tabuľky
     * @param h inštancia hráča
     */
    private void pridajHracaDoTabulky(Hrac h) {
        this.table.addRow(new Object[]{h.getId(), h.getMeno(), h.getSkore(), h.getLevel()});
    }

    /**
     * vytvorenie nového hráča, nastaví mú skóre na 0, ošetruje prípadné výnimky
     */
    public void vytvorHraca() {
        String meno = "";
        meno = JOptionPane.showInputDialog(null, "Zadaj meno", "Vytvorenie hráča", JOptionPane.INFORMATION_MESSAGE);
        try {
            if (meno.equals("") || meno == null) {
                throw new NespravneVyplnenePoleException("Neplatné meno");
            }
            for (Hrac h : this.hra.getZaciatocnici()) {
                if (h.getMeno().equals(meno)) {
                    throw new IllegalArgumentException("Hráč s rovnakým menom už existuje");
                }
            }
            for (Hrac h : this.hra.getPokrocili()) {
                if (h.getMeno().equals(meno)) {
                    throw new IllegalArgumentException("Hráč s rovnakým menom už existuje");
                }
            }
            Zaciatocnik novy = new Zaciatocnik(meno, this.hra.priradId());
            this.pridajHracaDoTabulky(novy);
            this.zoznamHracov.pridajHraca(novy);
            this.hra.pridajHraca(novy);
        } catch (NespravneVyplnenePoleException | IllegalArgumentException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
