package sk.uniza.fri.gui;

import sk.uniza.fri.Hra;
import sk.uniza.fri.Ukladanie;
import sk.uniza.fri.pouzivatelia.Admin;
import sk.uniza.fri.pouzivatelia.Hrac;
import sk.uniza.fri.pouzivatelia.Pokrocily;
import sk.uniza.fri.pouzivatelia.Zaciatocnik;
import sk.uniza.fri.vynimky.HracNenajdenyException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JMenu;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.table.DefaultTableModel;
import java.awt.Toolkit;
import java.awt.Dimension;
import java.awt.event.ActionEvent;

/**
 * 18. 4. 2022 - 15:45
 * grafické rozhranie pre admina
 * @author panak
 */
public class GuiAdminRozhranie {

    private final Admin admin;
    private final JFrame adminRozhranieFrame;

    private GuiMenu myGuiMenu;
    private final Hra hra;
    private JPanel uzivatelPane;
    private JMenuBar menuBar;
    private JPanel hornyPn;
    private JMenu suborJM;
    private JMenuItem odhlasitJMI;
    private JMenu upravyJM;
    private JMenuItem upravitJMI;
    private JMenuItem vymazatJMI;
    private JMenuItem hesloJMI;
    private JPanel strednyPn;
    private JPanel butonyPn;
    private JPanel tabulkaPn;
    private JScrollPane zaciatocniciPn;
    private JScrollPane pokrocilyPn;
    private JTable pokrTable;
    private JTable zacTable;
    private JButton menoBtn;
    private JButton vymazatBtn;

    private final DefaultTableModel tableModelZ;
    private final DefaultTableModel tableModelP;

    /**
     * Vytvorenie prostredia pre administrátora, ktoré obsahuje tabuľku používateľov. Admin môže upravovať mená hráčov, vymazávať ich a taktiež zmeniť svoje helso.
     * @param hra
     * @param admin
     */
    public GuiAdminRozhranie(Hra hra, Admin admin) {
        this.hra = hra;
        this.admin = admin;
        this.adminRozhranieFrame = new JFrame("Admin");
        this.adminRozhranieFrame.setResizable(false);
        this.adminRozhranieFrame.setContentPane(this.uzivatelPane);
        Toolkit t = Toolkit.getDefaultToolkit();
        Dimension d = t.getScreenSize();
        this.adminRozhranieFrame.setLocation(d.width / 50 * 20 - 300, d.height / 50 * 10);
        this.adminRozhranieFrame.pack();
        ImageIcon icon = new ImageIcon("C:/Users/panak/IdeaProjects/ver2.0/src/sk/uniza/fri/pics/kvet.png");
        this.adminRozhranieFrame.setIconImage(icon.getImage());
        this.adminRozhranieFrame.setVisible(true);
        this.adminRozhranieFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        this.odhlasitJMI.addActionListener(this::actionOdhlasit);
        this.hesloJMI.addActionListener(this::actionHeslo);
        this.vymazatBtn.addActionListener(this::actionVymazat);
        this.vymazatJMI.addActionListener(this::actionVymazat);
        this.upravitJMI.addActionListener(this::actionUprav);
        this.menoBtn.addActionListener(this::actionUprav);

        this.tableModelZ = new DefaultTableModel(
                new Object[][] {
                },
                new String [] {"Id", "Meno", "Skóre", "Level"}
        );

        this.tableModelP = new DefaultTableModel(
                new Object[][] {
                },
                new String [] {"Id", "Meno", "Skóre", "Level"}
        );
        
        this.pokrTable.setModel(this.tableModelP);
        this.pokrTable.getTableHeader().setReorderingAllowed(false);
        this.zacTable.setModel(this.tableModelZ);
        this.zacTable.getTableHeader().setReorderingAllowed(false);
        for (Pokrocily p : this.hra.getPokrocili()) {
            this.pridajHracaDoTabulky(p);
        }
        for (Zaciatocnik z :this.hra.getZaciatocnici()) {
            this.pridajHracaDoTabulky(z);
        }

    }

    /**
     * uprava hráčovho mena, následné aktualizovanie tabuľky
     * @param actionEvent
     */
    private void actionUprav(ActionEvent actionEvent) {
        try {
            int idUpravovaneho = Integer.parseInt(JOptionPane.showInputDialog(null, "Napíš id hráča, ktorého chceš upraviť", "Upravenie hríča", JOptionPane.INFORMATION_MESSAGE));
            if (this.hra.getPokrocili().getHraca(idUpravovaneho) != null) {
                String noveMeno = JOptionPane.showInputDialog(null, "Zadaj nové meno hráča", "Upraviť hríča", JOptionPane.WARNING_MESSAGE);
                int index = this.hra.getIndexHraca(this.hra.getPokrocili().getHraca(idUpravovaneho));
                this.tableModelP.removeRow(index);
                this.hra.getPokrocili().getHraca(idUpravovaneho).setMeno(noveMeno);
                this.pridajHracaDoTabulky(this.hra.getPokrocili().getHraca(idUpravovaneho));
                this.tableModelP.fireTableDataChanged();
            } else if (this.hra.getZaciatocnici().getHraca(idUpravovaneho) != null) {
                String noveMeno = JOptionPane.showInputDialog(null, "Zadaj nové meno hráča", "Upraviť hríča", JOptionPane.WARNING_MESSAGE);
                int index = this.hra.getIndexHraca(this.hra.getZaciatocnici().getHraca(idUpravovaneho));
                this.tableModelZ.removeRow(index);
                this.hra.getZaciatocnici().getHraca(idUpravovaneho).setMeno(noveMeno);
                this.pridajHracaDoTabulky(this.hra.getZaciatocnici().getHraca(idUpravovaneho));
                this.tableModelZ.fireTableDataChanged();
            } else {
                throw new HracNenajdenyException();
            }
        } catch (HracNenajdenyException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException ex) {

        }
    }

    /**
     * metóda umoží zmeniť administrátovrové heslo
     * @param actionEvent
     */
    private void actionHeslo(ActionEvent actionEvent) {
        try {
            String stareHeslo = JOptionPane.showInputDialog(null, "Zadaj staré heslo", "Zmena hesla", JOptionPane.QUESTION_MESSAGE);
            if (stareHeslo.equals(this.admin.getHeslo())) {
                String noveHeslo = JOptionPane.showInputDialog(null, "Zadaj nove heslo", "Zmena hesla", JOptionPane.QUESTION_MESSAGE);
                this.admin.setHeslo(noveHeslo);
                JOptionPane.showMessageDialog(null, "Heslo úspešne zmenené", "Zmena hesla", JOptionPane.INFORMATION_MESSAGE);
                Ukladanie.zapisAdmina(this.admin);
            } else {
                throw new IllegalArgumentException("Nesprávne heslo");
            }
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(null, "Netrafil si heslo", "Error", JOptionPane.ERROR_MESSAGE);
        }

    }

    /**
     * podľa zadaného id vymaže hráča
     * @param actionEvent
     */
    private void actionVymazat(ActionEvent actionEvent) {
        try {
            int idVymazaneho = Integer.parseInt(JOptionPane.showInputDialog(null, "Napíš id hráča, ktorého chceš vymazať", "Odstrániť hríča", JOptionPane.INFORMATION_MESSAGE));
            if (this.hra.getPokrocili().getHraca(idVymazaneho) != null) {
                JOptionPane.showMessageDialog(null, "Naozaj odstrániť zvoleného hráča?", "Odstrániť hríča", JOptionPane.WARNING_MESSAGE);
                int index = this.hra.getIndexHraca(this.hra.getPokrocili().getHraca(idVymazaneho));
                this.hra.getPokrocili().odstranHraca(this.hra.getPokrocili().getHraca(idVymazaneho));
                this.tableModelP.removeRow(index);
                this.tableModelP.fireTableDataChanged();
            } else if (this.hra.getZaciatocnici().getHraca(idVymazaneho) != null) {
                JOptionPane.showMessageDialog(null, "Naozaj odstrániť zvoleného hráča?", "Odstrániť hríča", JOptionPane.WARNING_MESSAGE);
                int index = this.hra.getIndexHraca(this.hra.getZaciatocnici().getHraca(idVymazaneho));
                this.hra.getZaciatocnici().odstranHraca(this.hra.getZaciatocnici().getHraca(idVymazaneho));
                this.tableModelZ.removeRow(index);
                this.tableModelZ.fireTableDataChanged();
            } else {
                throw new HracNenajdenyException();
            }
        } catch (HracNenajdenyException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);

        }
    }

    /**
     * vloženie hráča do tabuľky
     * @param h
     */
    private void pridajHracaDoTabulky(Hrac h) {
        if (h != null) {
            if (h instanceof Zaciatocnik) {
                this.tableModelZ.addRow(new Object[]{h.getId(), h.getMeno(), h.getSkore(), h.getLevel()});
            } else {
                this.tableModelP.addRow(new Object[]{h.getId(), h.getMeno(), h.getSkore(), h.getLevel()});
            }
        }
    }

    /**
     * odhlási administrátora a zavrie jeho rozhranie
     * @param actionEvent
     */
    private void actionOdhlasit(ActionEvent actionEvent) {
        JOptionPane.showMessageDialog(null, "Admin odhlásený");
        this.adminRozhranieFrame.dispose();
    }





}


