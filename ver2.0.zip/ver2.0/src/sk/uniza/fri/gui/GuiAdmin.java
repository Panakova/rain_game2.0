package sk.uniza.fri.gui;

import sk.uniza.fri.Hra;
import sk.uniza.fri.Ukladanie;
import sk.uniza.fri.pouzivatelia.Admin;
import sk.uniza.fri.vynimky.NespravneVyplnenePoleException;
import javax.swing.JFrame;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import javax.swing.JOptionPane;
import java.awt.Toolkit;
import java.awt.Dimension;
import java.awt.Color;
import java.awt.event.ActionEvent;

/**
 * 18. 4. 2022 - 15:45
 * Trieda slúži na grafickú reprezentáciu vytvrania administrátora
 * @author panak
 */
public class GuiAdmin {
    private Admin admin;
    private JTextField labelName;
    private JTextField labelPass1;
    private JTextField labelPass2;
    private JFrame adminFrame;
    private JPanel adminRegPanel;
    private final Hra hra;
    private JPanel adminLogPanel;

    public GuiAdmin(Hra hra, Admin admin) {
        this.hra = hra;
        this.admin = admin;

    }

    /**
     * Zobrati frame s textovými poľami pre registáciu.
     */
    public void registraciaAdmin () {
        Color c = new Color(204, 242, 255);
        this.adminRegPanel = new JPanel();
        this.adminFrame = new JFrame("Registrácia administrátora");
        ImageIcon icon = new ImageIcon("C:/Users/panak/IdeaProjects/ver2.0/src/sk/uniza/fri/pics/kvet.png");
        Toolkit t = Toolkit.getDefaultToolkit();
        Dimension d = t.getScreenSize();
        this.adminFrame.setLocation(d.width / 50 * 20, d.height / 50 * 10);
        this.adminFrame.setIconImage(icon.getImage());
        this.adminFrame.setSize(350, 210);
        this.adminFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.adminFrame.add(this.adminRegPanel);

        this.adminRegPanel.setLayout(null);
        JLabel labelMeno = new JLabel("Meno");
        labelMeno.setBounds(10, 20, 80, 25);
        this.adminRegPanel.add(labelMeno);
        this.labelName = new JTextField(20);
        this.labelName.setBounds(100, 20, 165, 25);
        this.adminRegPanel.add(this.labelName);

        JLabel labelHeslo = new JLabel("Heslo");
        labelHeslo.setBounds(10, 60, 80, 25);
        this.adminRegPanel.add(labelHeslo);
        this.labelPass1 = new JPasswordField(20);
        this.labelPass1.setBounds(100, 60, 165, 25);
        this.adminRegPanel.add(this.labelPass1);

        JLabel labelHeslo2 = new JLabel("Heslo znova");
        labelHeslo2.setBounds(10, 100, 80, 25);
        this.adminRegPanel.add(labelHeslo2);
        this.labelPass2 = new JPasswordField(20);
        this.labelPass2.setBounds(100, 100, 165, 25);
        this.adminRegPanel.add(this.labelPass2);

        JButton potvrdBtn = new JButton("Potvrď");
        potvrdBtn.setBackground(c);
        potvrdBtn.setBounds(120, 140, 80, 20);
        potvrdBtn.addActionListener(this::actionRegistration);
        this.adminRegPanel.add(potvrdBtn);

        this.adminFrame.setVisible(true);
        this.adminFrame.toFront();
    }

    /**
     * vykoná sa po stlačení tlačidla "Podvrď", ošetruje výnimky neprávne vyplnených polí.
     * @param e udalosť pri stlačení
     */
    public void actionRegistration(ActionEvent e) {
        try {
            String name = this.labelName.getText();
            String pas1 = this.labelPass1.getText();
            String pas2 = this.labelPass2.getText();
            if (name.equals("") || pas1.equals("") || pas2.equals("")) {
                throw new NespravneVyplnenePoleException("Prázdne pole");
            }
            try {
                if (pas1.equals(pas2)) {
                    String password = this.labelPass1.getText();
                    this.admin = new Admin(name, password);
                    this.hra.setAdmina(this.admin);
                    Ukladanie.zapisAdmina(this.admin);
                    JOptionPane.showMessageDialog(null, "Admin úspešne zaregistrovaný", "Registrácia", JOptionPane.INFORMATION_MESSAGE);
                    this.adminFrame.dispose();
                    new GuiAdminRozhranie(this.hra, this.admin);

                } else {
                    throw new NespravneVyplnenePoleException("Heslá sa nezhodujú");
                }
            } catch (NespravneVyplnenePoleException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NespravneVyplnenePoleException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * zobrazí panel pre prihlásenie admina
     */
    public void adminLogin() {
        if (this.hra.getAdmin() == null) {
            JOptionPane.showMessageDialog(null, "Admin nieje vytvorený", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        Color c = new Color(204, 242, 255);
        if (this.adminFrame != null) {
            this.adminFrame.remove(this.adminRegPanel);
        } else {
            this.adminFrame = new JFrame("Prihásenie administrátora");
        }
        this.adminLogPanel = new JPanel();
        ImageIcon icon = new ImageIcon("src/sk/uniza/fri/pics/kvet.png");
        Toolkit t = Toolkit.getDefaultToolkit();
        Dimension d = t.getScreenSize();
        this.adminFrame.setLocation(d.width / 50 * 20, d.height / 50 * 10);
        this.adminFrame.setIconImage(icon.getImage());
        this.adminFrame.setSize(350, 190);
        this.adminFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.adminFrame.add(this.adminLogPanel);

        this.adminLogPanel.setLayout(null);
        JLabel labelMeno = new JLabel("Meno");
        labelMeno.setBounds(10, 20, 80, 25);
        this.adminLogPanel.add(labelMeno);
        this.labelName = new JTextField(20);
        this.labelName.setBounds(100, 20, 165, 25);
        this.adminLogPanel.add(this.labelName);

        JLabel labelHeslo = new JLabel("Heslo");
        labelHeslo.setBounds(10, 60, 80, 25);
        this.adminLogPanel.add(labelHeslo);
        this.labelPass1 = new JPasswordField(20);
        this.labelPass1.setBounds(100, 60, 165, 25);
        this.adminLogPanel.add(this.labelPass1);

        JButton potvrdBtn = new JButton("Potvrď");
        potvrdBtn.setBackground(c);
        potvrdBtn.setBounds(120, 100, 80, 20);
        potvrdBtn.addActionListener(this::actionLog);
        this.adminLogPanel.add(potvrdBtn);

        this.adminFrame.setVisible(true);
        this.adminFrame.toFront();
    }

    /**
     * vykoná sa po stlačení tlačidla "Podvrď", ošetruje výnimky neprávne vyplnených polí.
     * @param e udalosť pri stlačení
     */
    public void actionLog(ActionEvent e) {
        try {
            String name = this.labelName.getText();
            String pas1 = this.labelPass1.getText();
            if (name.equals("") || pas1.equals("")) {
                throw new NespravneVyplnenePoleException("Prázdne pole");
            }
            try {
                if (this.hra.getAdmin() == null) {
                    this.adminFrame.dispose();
                    JOptionPane.showMessageDialog(null, "Najskôr vytvor admina", "Žiadny admin", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (pas1.equals(this.admin.getHeslo()) && name.equals(this.admin.getMeno())) {
                    JOptionPane.showMessageDialog(null, "Admin prihlásený", "Prihlásenie", JOptionPane.INFORMATION_MESSAGE);
                    this.adminFrame.dispose();
                    new GuiAdminRozhranie(this.hra, this.admin);
                } else {
                    throw new NespravneVyplnenePoleException("Nesprávne meno alebo heslo");
                }
            } catch (NespravneVyplnenePoleException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NespravneVyplnenePoleException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * getter
     * @return inštaniciu admina
     */
    public Admin getAdmin() {
        return this.admin;
    }
}
