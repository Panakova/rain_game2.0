package sk.uniza.fri.gui;

import sk.uniza.fri.Hra;
import sk.uniza.fri.pouzivatelia.Hrac;
import javax.swing.JFrame;
import javax.swing.ImageIcon;
import java.awt.Toolkit;
import java.awt.Dimension;

/**
 * 18. 4. 2022 - 15:45
 * Trieda vytvorí okno pre reprezenáciu hry
 * @author panak
 */
public class HraFrame extends JFrame {
    public HraFrame(Hra hra, Hrac hrac) {
        this.getContentPane().add(new HraPanel(hra, hrac, this));
        this.setTitle("Hra kvietok");
        this.setSize(350, 500);
        Toolkit t = Toolkit.getDefaultToolkit();
        Dimension d = t.getScreenSize();
        ImageIcon icon = new ImageIcon("C:/Users/panak/IdeaProjects/ver2.0/src/sk/uniza/fri/pics/kvet.png");
        this.setIconImage(icon.getImage());
        this.setLocation(d.width / 50 * 20, d.height / 50 * 10);
        this.setResizable(false);
        this.toFront();
        this.setVisible(true);
    }

    /**
     * zatvorí okno
     */
    public void zavri() {
        this.dispose();
    }

}
