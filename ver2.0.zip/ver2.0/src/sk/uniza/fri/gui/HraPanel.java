package sk.uniza.fri.gui;

import sk.uniza.fri.Hra;
import sk.uniza.fri.Narocnost;
import sk.uniza.fri.objekty.*;
import sk.uniza.fri.pouzivatelia.Hrac;
import sk.uniza.fri.pouzivatelia.Pokrocily;

import javax.swing.Timer;
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import java.awt.event.ActionEvent;
import java.awt.Graphics;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Random;

/**
 * 18. 4. 2022 - 15:45
 * vytvorí rozhranie pre Hru.
 * @author panak
 */
public class HraPanel extends JPanel implements ActionListener {

    private final Kvietok kvietok;
    private final ArrayList<PadajuceObjekty> padajuceObjekty;

    private final Hra hra;
    private final Hrac hrac;
    private final Narocnost narocnost;
    private ImageIcon pozadieHry;
    private final Timer timer;
    private final HraFrame frame;

    public HraPanel(Hra hra, Hrac hrac, HraFrame frame) {
        this.hra = hra;
        this.hrac = hrac;
        this.pozadieHry = new ImageIcon("C:/Users/panak/IdeaProjects/ver2.0/src/sk/uniza/fri/pics/pozadie.png");
        this.kvietok = new Kvietok();
        this.hrac.setZivoty(3);
        if (hrac instanceof Pokrocily) {
            this.pokrocileMoznosti();
        }
        this.narocnost = this.hrac.setNarocnost();
        this.padajuceObjekty = new ArrayList<>();
        this.timer = new Timer(40, this);
        this.timer.start();
        this.frame = frame;
        this.setFocusable(true);
        this.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                super.keyPressed(e);
                if (e.getKeyCode() == KeyEvent.VK_LEFT) {
                    HraPanel.this.kvietok.posunVlavo();
                } else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
                    HraPanel.this.kvietok.posunVpravo();
                }
            }
        });

    }

    /**
     * metóda sa zobrazí iba hráčovi, ktorý má vysoké skóre. môže si vybrať farbu kvietku a tému prostredia
     */
    private void pokrocileMoznosti() {
        String[] poleFarieb = {"Červená", "Fialová", "Modrá", "Žltá"};
        String volba = (String) JOptionPane.showInputDialog(null, "Zvol si farbu kvietku", "Odomknutá úroven", JOptionPane.QUESTION_MESSAGE, null, poleFarieb, poleFarieb[0]);
        if (volba != null) {
            switch (volba) {
                case "Červena" -> this.kvietok.setObrazok(new ImageIcon("C:/Users/panak/IdeaProjects/ver2.0/src/sk/uniza/fri/pics/kvet.png"));
                case "Fialová" -> this.kvietok.setObrazok(new ImageIcon("C:/Users/panak/IdeaProjects/ver2.0/src/sk/uniza/fri/pics/kvet_F.png"));
                case "Modrá" -> this.kvietok.setObrazok(new ImageIcon("C:/Users/panak/IdeaProjects/ver2.0/src/sk/uniza/fri/pics/kvet_M.png"));
                case "Žltá" -> this.kvietok.setObrazok(new ImageIcon("C:/Users/panak/IdeaProjects/ver2.0/src/sk/uniza/fri/pics/kvet_Z.png"));
            }
        }
        String[] btns = {"Den", "Noc"};
        int tema = JOptionPane.showOptionDialog(null, "Nastav si pozadie", "Odmoknutá úroven", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null, btns, 0);
        switch (tema) {
            case 0:
                this.pozadieHry = new ImageIcon("C:/Users/panak/IdeaProjects/ver2.0/src/sk/uniza/fri/pics/pozadie.png");
                break;
            case 1:
                this.pozadieHry = new ImageIcon("C:/Users/panak/IdeaProjects/ver2.0/src/sk/uniza/fri/pics/pozadie_noc.png");
                break;
            default:
                break;
        }
    }

    /**
     * metóda, ktorá sa vykonáva v intervaloch
     * @param e
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        this.repaint();
        this.noveObjekty();
    }

    /**
     * vytvára nové objekty podľa náročnosti, ktorú si hráč zvolil
     */
    public void noveObjekty() {
        Random r = new Random();
        if (r.nextDouble() < this.narocnost.getCislo(this.narocnost) ) {
            this.padajuceObjekty.add(this.novyObjekt(r.nextInt(320)));
        }
        if (this.padajuceObjekty.size() > 0) {
            for (int i = 0; i < this.padajuceObjekty.size(); i++) {
                if (this.ciChytil(i)) {
                    //polymorfizmus
                    this.padajuceObjekty.get(i).aktivuj(this.hrac);
                    this.padajuceObjekty.remove(i);
                    if (this.hrac.getPocetZivotov() == 0) {
                        this.koniecHry();
                        break;
                    }
                    //sťažovanie náročnosti
                    if (this.hrac.getSkore() % 10 == 0) {
                        PadajuceObjekty.zrychli();
                    }
                }
            }
        }
    }

    /**
     * kontroluje kolíziu
     * @param i index objektu
     * @return či nastala kolízia
     */
    public boolean ciChytil(int i) {
        //ak nestihol kvapku uber, inak nic
        //ak chytil aktivuj

        PadajuceObjekty o = this.padajuceObjekty.get(i);
        boolean chytil = false;
        //pozície, v ktorej akceptujeme že hráč chytil kvapku
        if (this.kvietok.getPozX() + 32 >= o.getPozX() && this.kvietok.getPozX() <= o.getPozX()
                && o.getPozY() >= 310 && o.getPozY() <= 430) {
            chytil = true;
        } else if (o.getPozY() > 430) {
            if (o instanceof Kvapka) {
                //dolná hranica, kedy už hráč kvapku chytiť nestihol
                this.hrac.uberZivot();
            }
            //ak nechytil bombu tak sa hráčovi neuberie život
            this.padajuceObjekty.remove(o);
            if (this.hrac.getPocetZivotov() == 0) {
                this.koniecHry();
            }
        }
        return chytil;
    }

    /**
     * ukonči grafické prostredie pre hru a uloží hráča do tabulky
     */
    public void koniecHry() {
        this.timer.stop();
        String vypis = "Tvoje skóre je: " + this.hrac.getSkore();
        JOptionPane.showMessageDialog(null, vypis, "Koniec hry" , JOptionPane.PLAIN_MESSAGE);
        this.hra.kontorlujHracov();
        this.frame.zavri();
    }

    /**
     * vykresľuje objekty na obrazovku
     * @param g grafika
     */
    public void paintComponent(Graphics g) {
        g.drawImage(this.pozadieHry.getImage(), 0, 0, this);
        g.drawImage(this.kvietok.getObrazok().getImage(), this.kvietok.getPozX(), this.kvietok.getPozY(), this);
        String skore = "Skore: " + this.hrac.getSkore();
        g.drawString(skore, 20, 20);
        this.kresliObjekty(g);
        this.kresliZivoty(g);
    }

    /**
     * zobrazí príslušné životy hráča
     * @param g grafika
     */
    private void kresliZivoty(Graphics g) {
        for (int i = 0; i < this.hrac.getPocetZivotov(); i++) {
            Zivot z = new Zivot(260 + (i * 15));
            g.drawImage(z.getImage(), z.getPozX(), z.getPozY(), this);
        }
    }
    public void kresliObjekty(Graphics g) {
        if (this.padajuceObjekty != null) {
            for (PadajuceObjekty o : this.padajuceObjekty) {
                o.padaj();
                g.drawImage(o.getImage(), o.getPozX(), o.getPozY(), this);
            }
        }
    }

    /**
     * vytvára nové objekty
     * @param kde x suradnica vytvorenia
     * @return objekt vytvorený na danej pozícií
     */
    public PadajuceObjekty novyObjekt(int kde) {
        PadajuceObjekty o = null;
        Random r = new Random();
        double cislo = r.nextDouble();
        if (cislo < 0.1) {
            o = new Zivot(kde);
        } else if (cislo < 0.3) {
            o = new Bomba(kde);
        } else if (cislo < 0.5) {
            o = new Kamen(kde);
        } else {
            o = new Kvapka(kde);
        }
        return o;
    }
    /**
     * metóda pre test
     */
    public void vytvorObjekt () {
        Kvapka k = new Kvapka(155);
        k.spadni(400);
        this.padajuceObjekty.add(k);
    }
}
