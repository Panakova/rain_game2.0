package sk.uniza.fri.gui;

import sk.uniza.fri.Hra;
import sk.uniza.fri.Ukladanie;
import sk.uniza.fri.pouzivatelia.Admin;
import sk.uniza.fri.pouzivatelia.Pokrocily;
import sk.uniza.fri.pouzivatelia.Zaciatocnik;
import sk.uniza.fri.pouzivatelia.IPouzivatel;
import sk.uniza.fri.pouzivatelia.Hrac;
import sk.uniza.fri.vynimky.NespravneVyplnenePoleException;

import javax.swing.JFrame;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import java.awt.Toolkit;
import java.awt.Dimension;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * 18. 4. 2022 - 15:45
 * Trieda pre grafickú repredentáciu menu hry
 * @author panak
 */
public class GuiMenu {
    private final Hra hra;
    private Admin admin;
    private final JFrame frame;
    private final Color color;
    private final ImageIcon backgroundMenu;

    /**
     * Konštruktor, ktorý nam zabezpačí inicializáciu atribútov
     *
     * @param hra   inštanicia hry
     * @param admin inštancia admina
     */
    public GuiMenu(Hra hra, Admin admin) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Nepodarilo sa načítať tému");
        }
        this.hra = hra;
        this.admin = admin;
        this.color = new Color(204, 242, 255);
        this.backgroundMenu = new ImageIcon("C:/Users/panak/IdeaProjects/ver2.0/src/sk/uniza/fri/pics/menu.png");
        this.frame = new JFrame("Hra");
        this.frame.setSize(350, 500);
        Toolkit t = Toolkit.getDefaultToolkit();
        Dimension d = t.getScreenSize();
        this.frame.setLocation(d.width / 50 * 20, d.height / 50 * 10);
        this.frame.setResizable(false);
        this.frame.setLayout(null);
        this.frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        this.frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                Ukladanie.ulozHru(GuiMenu.this.hra);
                System.exit(0);
            }

        });
        this.frame.getContentPane().setBackground(new Color(204, 242, 255));
        ImageIcon icon = new ImageIcon("C:/Users/panak/IdeaProjects/ver2.0/src/sk/uniza/fri/pics/kvet.png");
        this.frame.setIconImage(icon.getImage());
        this.oknoMenu();
    }

    /**
     * zobrazí okno menu
     */
    public void oknoMenu() {
        JPanel panel = new JPanel();
        panel.setBounds(0, 0, 350, 500);
        panel.setLayout(null);

        JLabel background = new JLabel(this.backgroundMenu);
        background.setVisible(true);
        background.setBounds(0, 0, 350, 500);

        JButton b1 = new JButton("Hrať");
        b1.setBounds(200, 150, 120, 20);
        b1.setBackground(this.color);
        panel.add(b1);
        b1.addActionListener(this::actionHrat);

        JButton b2 = new JButton("Zoznam používateľov");
        b2.setBounds(200, 200, 120, 20);
        b2.setBackground(this.color);
        panel.add(b2);
        b2.addActionListener(this::actionZoznamHier);

        JButton b3 = new JButton("Najlepší hráč");
        b3.setBounds(200, 250, 120, 20);
        b3.setBackground(this.color);
        panel.add(b3);
        b3.addActionListener(this::actionNajlepsiHrac);

        JButton b4 = new JButton("Vyhľadaj hráča");
        b4.setBounds(200, 300, 120, 20);
        b4.setBackground(this.color);
        panel.add(b4);
        b4.addActionListener(this::actionHladajHraca);

        JButton b5 = new JButton("Rozšírené");
        b5.setBounds(200, 430, 120, 20);
        b5.setBackground(this.color);
        panel.add(b5);
        b5.addActionListener(this::actionRozsirene);

        panel.setVisible(true);
        panel.add(background);
        this.frame.add(panel);
        this.frame.setVisible(true);

    }

    /**
     * zobrazí používateľovi zoznam všetkých hier, používa triedu Collections na zoradenie hráčov podľa id
     *
     * @param actionEvent udalosť stlačenia tlačidla
     */
    public void actionZoznamHier(ActionEvent actionEvent) {
        ArrayList<IPouzivatel> pouzivatelia = new ArrayList<>();
        pouzivatelia.add(this.admin);
        for (Zaciatocnik z : this.hra.getZaciatocnici()) {
            pouzivatelia.add(z);
        }
        for (Pokrocily p : this.hra.getPokrocili()) {
            pouzivatelia.add(p);
        }
        Collections.sort(pouzivatelia, new Comparator<IPouzivatel>() {
            @Override
            public int compare(IPouzivatel o1, IPouzivatel o2) {
                return o1.getId() - o2.getId();
            }
        });
        String vypis = "";
        for (IPouzivatel p : pouzivatelia) {
            vypis += p.vypis() + "\n";
        }
        JOptionPane.showMessageDialog(null, vypis, "Zoznam používateľov", JOptionPane.PLAIN_MESSAGE);
    }

    /**
     * prístup k rozšíreným možnostiam pre admina
     *
     * @param e udalosť stlačenia tlačidla
     */
    public void actionRozsirene(ActionEvent e) {
        String[] narocnosti = {"Registrovať", "Prihlásiť"};
        int volba = JOptionPane.showOptionDialog(null, "Zadaj admina", "Rozšírené", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null, narocnosti, 0);
        switch (volba) {
            case 0:
                if (this.admin == null) {
                    GuiAdmin gui = new GuiAdmin(this.hra, this.admin);
                    gui.registraciaAdmin();
                    this.admin = gui.getAdmin();

                } else {
                    JOptionPane.showMessageDialog(null, "Admin už je vytvorený");
                }
                break;
            case 1:
                GuiAdmin gui = new GuiAdmin(this.hra, this.admin);
                gui.adminLogin();
                break;
            default:
        }
    }

    /**
     * zobrazá rozhranie , kde si používateľ zvolení hráča pre hru
     *
     * @param e udalosť stlačenia tlačidla
     */
    public void actionHrat(ActionEvent e) {
        new GuiHrac(this.hra);
    }

    /**
     * Zobrazí hráča s najvyšším skóre
     *
     * @param e udalosť stlačenia tlačidla
     */
    public void actionNajlepsiHrac(ActionEvent e) {
        ImageIcon vyhra = new ImageIcon("src/sk/uniza/fri/pics/winner_cup.png");
        Hrac najlepsi = null;
        int najlepsieSkore = 0;
        //prehľadavanie zoznamov hráčov
        for (Hrac h : this.hra.getPokrocili()) {
            if (najlepsieSkore < h.getSkore()) {
                najlepsieSkore = h.getSkore();
                najlepsi = h;
            }
        }
        for (Hrac h : this.hra.getZaciatocnici()) {
            if (najlepsieSkore < h.getSkore()) {
                najlepsieSkore = h.getSkore();
                najlepsi = h;
            }
        }
        JOptionPane.showConfirmDialog(null, najlepsi.vypis(), "Najlepší hráč je", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, vyhra);

    }

    /**
     * otvorí okno pre vyhľadanie konkrétneho hráča
     *
     * @param e udalosť stlačenia tlačidla
     */
    public void actionHladajHraca(ActionEvent e) {
        try {
            //zadanie hľadaného hráča
            String hladany = "";
            hladany = JOptionPane.showInputDialog(null, "Zadaj meno hráča");
            if (hladany.equals("")) {
                throw new NespravneVyplnenePoleException("Prazdne pole");
            }
            //prehľadávanie v zozname
            for (Pokrocily pokrocily : this.hra.getPokrocili()) {
                if (pokrocily.getMeno().equals(hladany)) {
                    JOptionPane.showMessageDialog(null, pokrocily.vypis(), "Hľadanie hráča", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
            }
            for (Zaciatocnik zaciatocnik : this.hra.getZaciatocnici()) {
                if (zaciatocnik.getMeno().equals(hladany)) {
                    JOptionPane.showMessageDialog(null, zaciatocnik.vypis(), "Hľadanie hráča", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
            }
            JOptionPane.showMessageDialog(null, "Hráč nebol nájdený", "Hľadanie hráča", JOptionPane.ERROR_MESSAGE);
        } catch (NespravneVyplnenePoleException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Hľadanie hráča", JOptionPane.ERROR_MESSAGE);
        } catch (NullPointerException ex) {

        }
    }
}