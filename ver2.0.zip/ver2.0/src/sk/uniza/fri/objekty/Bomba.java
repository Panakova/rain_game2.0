package sk.uniza.fri.objekty;

import sk.uniza.fri.pouzivatelia.Hrac;

/**
 * 27. 3. 2022 - 19:33
 * objekt bomba, ktorý je potomkom PadajuceObjekty
 * @author panak
 */
public class Bomba extends PadajuceObjekty {

    public Bomba(int pozX) {
        super(pozX);
        super.setObrazok("bomba");
    }

    /**
     * implemetnováná abstraktná metóda, ktorá uberie hráčovi všetky životy
     * @param hrac inštancia hráča
     */
    public void aktivuj(Hrac hrac) {
        hrac.setZivoty(0);
    }




}
