package sk.uniza.fri.objekty;


import sk.uniza.fri.pouzivatelia.Hrac;

/**
 * 27. 3. 2022 - 19:33
 * objekt kamen, ktorý je potomkom PadajuceObjekty
 * @author panak
 */
public class Kamen extends PadajuceObjekty {


    public Kamen(int pozX) {
        super(pozX);
        super.setObrazok("kamen");
    }

    /**
     * implemetnováná abstraktná metóda, ktorá uberie hráčovi jeden život
     * @param hrac inštancia hráča
     */
    @Override
    public void aktivuj(Hrac hrac) {
        hrac.uberZivot();

    }


}
