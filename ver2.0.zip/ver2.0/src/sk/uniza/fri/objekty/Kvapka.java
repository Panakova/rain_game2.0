package sk.uniza.fri.objekty;

import sk.uniza.fri.pouzivatelia.Hrac;

/**
 * Trieda nám vytvorí kvapku
 * 
 * @author (Rebeka Panáková) 
 * @version (16.12.2021)
 */
public class Kvapka extends PadajuceObjekty {

    /**
     * Konštruktor triedy Kvapka vytvorí kvapku na danej 
     * suradnici x a y
     * 
     * @param pozX je x suradnica kde sa ma kvapka vytvorit 
     */
    public Kvapka(int pozX) {
        super(pozX);
        super.setObrazok("kvapka");
    }

    /**
     * implemetnováná abstraktná metóda, ktorá pripíše hráčcovi jeden bod
     * @param hrac inštancia hráča
     */
    public void aktivuj(Hrac hrac) {
        hrac.pripisSkore();
    }

    public void spadni(int kolko) {
        super.setPozY(kolko);
    }
}
