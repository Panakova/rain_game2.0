package sk.uniza.fri.objekty;

import sk.uniza.fri.pouzivatelia.Hrac;

import javax.swing.ImageIcon;
import java.awt.Image;

/**
 * 27. 3. 2022 - 19:33
 * všeobecný predok objektov, ktoré sa vyskytujú v hre
 * @author panak
 */
public abstract class PadajuceObjekty {
    //atribúty triedy
    private static int rychlost = 4;
    //atributy inštancie
    private ImageIcon obrazok;
    private final int pozX; //súradnica objektu x
    private int pozY; //súradnica objektu y

    public PadajuceObjekty (int pozX) {
        this.pozX = pozX;
        this.pozY = 0;
        this.obrazok = null;
    }
    //metóda triedy

    /**
     * zvýši rýchlosť padania objektu
     */
    public static void zrychli() {
        rychlost += 1;
    }

    protected void setObrazok(String nazov) {
        this.obrazok = new ImageIcon("C:/Users/panak/IdeaProjects/ver2.0/src/sk/uniza/fri/pics/" + nazov + ".png");
    }

    /**
     * @return vrati pozíciu x
     */
    public int getPozX() {
        return this.pozX;
    }

    /**
     * @return vrati pozíciu y
     */
    public int getPozY() {
        return this.pozY;
    }

    /**
     * abstraktná metoda, každý potomok bude môcť metódu využiť inak
     * @param hrac
     */
    public abstract void aktivuj(Hrac hrac);

    /**
     * posunie pozíciu objektu o jeho rýchlosť nižšie
     */
    public void padaj() {
        this.pozY += PadajuceObjekty.rychlost;
    }
    public Image getImage() {
        return this.obrazok.getImage();
    }
    protected void setPozY(int y) {
        this.pozY = y;
    }

}
