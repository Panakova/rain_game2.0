package sk.uniza.fri.objekty;

import sk.uniza.fri.pouzivatelia.Hrac;

/**
 * 27. 3. 2022 - 19:33
 * objekt život, ktorý je potomkom PadajuceObjekty
 * @author panak
 */
public class Zivot extends PadajuceObjekty {

    public Zivot(int pozX) {
        super(pozX);
        super.setObrazok("heart");

    }
    /**
     * implemetnováná abstraktná metóda, ktorá pridá hráčovi život
     * @param hrac inštancia hráča
     */
    @Override
    public void aktivuj(Hrac hrac) {
        hrac.pridajZivot();
    }




}
