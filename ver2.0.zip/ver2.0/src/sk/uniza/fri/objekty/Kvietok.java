package sk.uniza.fri.objekty;

import javax.swing.*;

/**
 * Trieda Kvietok vytvorí jedinú inštanciu kvietku, ktorým používaťeľ hrá hru. 
 * 
 * @author (Rebeka Panáková) 
 * @version (28.12.2021)
 */
public class Kvietok {
    //atribúty inštancie
    private ImageIcon obrazok;
    private int pozX;
    private final int pozY;
    private final JLabel kvetLb;
    /**
     * Privátny konštruktor vytvorí inštanciu triedy
     */
    public Kvietok() {
        //inicializácia atribútov
        this.pozX = 150; // pozícia X
        this.pozY = 320; //pozícia Y
        this.obrazok = new ImageIcon("C:/Users/panak/IdeaProjects/ver2.0/src/sk/uniza/fri/pics/kvet.png"); //načítanie obrázku kvietka zo súboru
        this.kvetLb = new JLabel();
        this.kvetLb.setIcon(this.obrazok);
        this.kvetLb.setBounds(this.pozX, this.pozY, this.obrazok.getIconWidth(), this.obrazok.getIconHeight());

    }
    /**
     * šípkami ovladané príkazy na posun v rozmedzí hraej plochy
     */
    public void posunVpravo() {
        if (this.pozX >= -5 && this.pozX <= 290) {
            this.pozX += 5;
        }
    }
    
    /**
     * šípkami ovladané príkazy na posun v rozmedzí hraej plochy
     */
    public void posunVlavo() {
        if (this.pozX >= 0 && this.pozX <= 295) {
            this.pozX -= 5;
        }
    }
    
    /**
     * @return pozíciu x, na ktorej sa práve nachádza
     */
    public int getPozX() {
        return this.pozX;
    }
    
    /**
     * @return pozíciu y, na ktorej sa práve nachádza
     */
    public int getPozY() {
        return this.pozY;
    }

    public ImageIcon getObrazok() {
        return this.obrazok;
    }

    public void setObrazok(ImageIcon obrazok) {
        this.obrazok = obrazok;
    }
}
