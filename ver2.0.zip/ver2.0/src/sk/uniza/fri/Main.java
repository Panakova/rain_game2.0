package sk.uniza.fri;
/**
 * Created by IntelliJ IDEA.
 * User: panak
 * Date: 18. 4. 2022
 * Time: 15:45
 */
public class Main {

    public static void main(String[] args) {

        Hra h = new Hra();
    }
}
