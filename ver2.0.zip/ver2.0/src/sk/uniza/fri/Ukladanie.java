package sk.uniza.fri;

import sk.uniza.fri.pouzivatelia.Admin;
import sk.uniza.fri.pouzivatelia.Pokrocily;
import sk.uniza.fri.pouzivatelia.Zaciatocnik;
import javax.swing.JOptionPane;
import java.io.File;
import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.EOFException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 * 18. 4. 2022 - 15:45
 * trieda súži na zapisovaie do binárnych a textových súborov
 * @author panak
 */
public class Ukladanie {
    //metódy triedy
    /**
     * zápis hračov do súobru
     * @param hra inštancia hry
     */
    public static void ulozHru(Hra hra) {
        PrintWriter writer = null;
        try {
            writer = new PrintWriter(new File("C:\\Users\\panak\\IdeaProjects\\ver2.0\\hry.txt"));
            for (Zaciatocnik zHrac : hra.getZaciatocnici()) {
                writer.write(zHrac.toString() + "\n");
            }
            for (Pokrocily pHrac : hra.getPokrocili()) {
                writer.write(pHrac.toString() + "\n");
            }
            writer.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error" , JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * načítanie hier zo súboru
     * @param hra inštancia do ktorej načítavame informácie
     */
    public static void nacitajHru(Hra hra) {
        Scanner citac = null;
        try {
            citac = new Scanner(new File("C:\\Users\\panak\\IdeaProjects\\ver2.0\\hry.txt"));
            while (citac.hasNextLine()) {

                int idH = citac.nextInt();
                String meno = citac.next();
                int skore = citac.nextInt();
                String level = citac.nextLine().replace(" ", "");
                try {
                    if (level.equals("Pokročilý")) {
                        hra.pridajHraca(new Pokrocily(idH, meno, skore));
                    } else {
                        hra.pridajHraca(new Zaciatocnik(idH, meno, skore));
                    }
                } catch (IllegalArgumentException ile) {
                    JOptionPane.showMessageDialog(null, ile.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
            citac.close();
        } catch (FileNotFoundException ex) {
            System.out.println("subor nenajdeny " + ex.getMessage());
        }
    }

    /**
     * zapisanie administrátora do binárneho súboru
     * @param admin
     */
    public static void zapisAdmina(Admin admin) {
        DataOutputStream writer = null;
        try {
            writer = new DataOutputStream(new FileOutputStream(new File("C:\\Users\\panak\\IdeaProjects\\ver2.0\\admin.dat")));
            writer.writeUTF(admin.getMeno());
            writer.writeUTF(admin.getHeslo());
            writer.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error" , JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * načitanie z binarneho suboru
     * @return
     */
    public static Admin nacitajAdmina() {
        DataInputStream citac = null;
        try {
            boolean koniecSuboru = false;
            citac = new DataInputStream(new FileInputStream("C:\\Users\\panak\\IdeaProjects\\ver2.0\\admin.dat"));
            while (!koniecSuboru) {
                try {
                    String meno = citac.readUTF();
                    String heslo = citac.readUTF();
                    try {
                        return new Admin(meno, heslo);
                    } catch (IllegalArgumentException ile) {
                        JOptionPane.showMessageDialog(null, ile.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (EOFException eof) {
                    koniecSuboru = true;
                    citac.close();
                }
            }
            citac.close();
        } catch (FileNotFoundException ex) {
            System.out.println("subor nenajdeny " + ex.getMessage());
        } catch (IOException e) {
            System.out.println("chyba pri zatvarani subrou" + e.getMessage());
        }
        return null;
    }
}
