package sk.uniza.fri.vynimky;

import java.io.IOException;

/**
 * 18. 4. 2022 - 15:45
 *
 * @author panak
 */
public class NespravneVyplnenePoleException extends Exception {
    public NespravneVyplnenePoleException(String message) {
        super("Nesprávne vyplnené pole: " + message);
    }
}
