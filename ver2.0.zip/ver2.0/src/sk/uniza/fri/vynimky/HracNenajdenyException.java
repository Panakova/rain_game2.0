package sk.uniza.fri.vynimky;

/**
 * 27. 3. 2022 - 19:33
 *
 * @author panak
 */
public class HracNenajdenyException extends IllegalArgumentException {
    public HracNenajdenyException() {
        super("Nenájdený hráč");
    }
}
