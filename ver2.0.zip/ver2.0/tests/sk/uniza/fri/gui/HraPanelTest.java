package sk.uniza.fri.gui;

import junit.framework.TestCase;
import org.junit.Assert;
import sk.uniza.fri.Hra;
import sk.uniza.fri.objekty.Kvapka;
import sk.uniza.fri.pouzivatelia.Hrac;

/**
 * 18. 4. 2022 - 15:45
 *
 * @author panak
 */
public class HraPanelTest extends TestCase {
    private HraPanel panel;
    private Hra hra;

    public void setUp() throws Exception {
        super.setUp();
        this.hra = new Hra();
        Hrac hrac = new Hrac("Skuska", 0);
        this.panel = new HraPanel(this.hra, hrac, new HraFrame(this.hra, hrac));
    }

    public void testCiChytil() {
        this.panel.vytvorObjekt();
        Assert.assertTrue(this.panel.ciChytil(0));
    }
}